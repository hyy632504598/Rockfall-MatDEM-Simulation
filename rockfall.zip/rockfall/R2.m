clear;
load('TempModel/R1.mat');
B.setUIoutput();
d=B.d;
d.calculateData();
d.mo.setGPU('off');
d.getModel();

matTxt1=load('Mats\mxRock2.txt');
Mats{1,1}=material('mxRock2',matTxt1,B.ballR);
Mats{1,1}.Id=1;
matTxt2=load('Mats\mxSoil.txt');
Mats{2,1}=material('mxSoil',matTxt2,B.ballR);
Mats{2,1}.Id=2;
d.Mats=Mats;

C=Tool_Cut(d);%cut the model
lSurf=load('rockfall/S1.txt');%load the surface data
C.addSurf(lSurf);%add the surfaces to the cut
C.setLayer({'sample'},[1,2,3]);%set layers according geometrical data
gNames={'lefPlaten';'rigPlaten';'botPlaten';'layer1';'layer2'};
d.makeModelByGroups(gNames);

B.setPlatenFixId();
d.addFixId('X',d.GROUP.layer2);
d.addFixId('Y',d.GROUP.layer2);
d.addFixId('Z',d.GROUP.layer2);
d.addFixId('X',d.GROUP.sample);
d.addFixId('Y',d.GROUP.sample);
d.addFixId('Z',d.GROUP.sample);
d.setGroupMat('layer1','mxSoil');
d.setGroupMat('layer2','mxSoil');
d.groupMat2Model({'sample'});
d.balanceBondedModel();
d.show('ZDisplacement');

rock=mfs.denseModel(0.8,@mfs.makeBox,0.092,0.092,0.092,0.01);
rockId=d.addElement(1,rock,'model');
d.addGroup('rock',rockId);
d.setGroupMat('rock','mxRock2');
d.groupMat2Model({'sample'});
d.moveGroup('rock',0.1,0,63.2);
d.setClump('rock');

d.defineWallElement('layer1');

d.balanceBondedModel0();%balance the bonded model without friction
d.show('aMatId');
d.clearData(1);%clear dependent data
d.recordCalHour('R2Finish');

d.mo.setGPU('off');
d.clearData(1);%clear dependent data in d
d.recordCalHour('R2Finsh');
save(['TempModel/' B.name '2.mat'],'B','d');
save(['TempModel/' B.name '2R' num2str(B.ballR) '-distri' num2str(B.distriRate)  'aNum' num2str(d.aNum) '.mat']);
d.calculateData();
d.show();