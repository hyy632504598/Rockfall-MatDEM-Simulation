%Please enter your commands here.
clear;
fs.randSeed(1);
B=obj_Box;
B.name='R';
B.GPUstatus='auto';
B.ballR=0.3;
B.distriRate=0;
B.sampleW=75;
B.sampleL=2;
B.sampleH=65;
B.type='GeneralSlope';
B.setType();
B.buildInitialModel();
B.setUIoutput();

d=B.d;

d.mo.setGPU('auto');

B.gravitySediment();
B.compactSample(3);
mfs.reduceGravity(d,10);

d.status.dispEnergy();%display the energy of the model

d.clearData(1);%clear dependent data
d.recordCalHour('R1Finish');
save(['TempModel/' B.name '1.mat'],'B','d');
save(['TempModel/' B.name '1R' num2str(B.ballR) '-distri' num2str(B.distriRate)  'aNum' num2str(d.aNum) '.mat']);
d.calculateData();
d.show('aR');